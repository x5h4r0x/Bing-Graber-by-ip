﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading.Thread
Imports Bing_Grabber.My
Imports Microsoft.VisualBasic.CompilerServices


Public Class Form1
    Dim i1 As Integer
    Dim thread As System.Threading.Thread
    Dim thread2 As System.Threading.Thread
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Control.CheckForIllegalCrossThreadCalls = False
    End Sub
    Private Sub cop()
        Dim stringBuilder As StringBuilder = New StringBuilder()
        Dim arg_1B_0 As Integer = 0
        Dim num As Integer = Me.ListBox1.Items.Count - 1
        Dim num2 As Integer = arg_1B_0
        While True
            Dim arg_50_0 As Integer = num2
            Dim num3 As Integer = num
            If arg_50_0 > num3 Then
                Exit While
            End If
            stringBuilder.Append(Me.ListBox1.Items(num2).ToString())
            stringBuilder.Append(vbCrLf)
            num2 += 1
        End While
        MyProject.Computer.Clipboard.SetText(stringBuilder.ToString())

    End Sub
    Private Sub deledup()
        Dim arrayList As ArrayList = New ArrayList()
        Try
            Dim enumerator As IEnumerator = Me.ListBox1.Items.GetEnumerator()
            While enumerator.MoveNext()
                Dim text As String = Conversions.ToString(enumerator.Current)
                Dim flag As Boolean = Not arrayList.Contains(text)
                If flag Then
                    arrayList.Add(text)
                End If
            End While
        Finally

        End Try
        Me.ListBox1.Items.Clear()
        Try
            Dim enumerator2 As IEnumerator = arrayList.GetEnumerator()
            While enumerator2.MoveNext()
                Dim item As String = Conversions.ToString(enumerator2.Current)
                Me.ListBox1.Items.Add(item)
            End While
        Finally

        End Try
        Me.Label1.Text = Conversions.ToString(Me.ListBox1.Items.Count)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox2.Text = "" Or TextBox2.Text = "0" Or RichTextBox1.Text = "" Then


            MsgBox("add ip and domain get")

        Else
            thread = New System.Threading.Thread(AddressOf bing)

            Me.thread.Start()
            Dim sw As New System.IO.StreamWriter("ip.txt")

            For Each sLine As String In RichTextBox1.Lines
                sw.WriteLine(sLine)

            Next
            sw.Close()

        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        thread2 = New System.Threading.Thread(AddressOf deledup)

        Me.thread2.Start()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.cop()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.TextBox1.Text = ""
        Me.Label1.Text = ".."
        Me.ListBox1.Items.Clear()
        Me.ProgressBar1.Value = 0
    End Sub
    ' WindowsApplication1.Form1
    Private Sub bing()
        Dim array As String() = Me.TextBox1.Text.Split(New Char() {vbCr})
        Dim array2 As String() = array
        For i As Integer = 0 To RichTextBox1.Lines.Length - 1
            TextBox1.Text &= RichTextBox1.Lines(i) & If(i < RichTextBox1.Lines.Length - 1, Environment.NewLine, "")
            Dim ipsite As String

            Dim text As String = TextBox1.Text
            Dim webClient As WebClient = New WebClient()
            Dim pattern As String = "<h2><a href=""(.*?)"" h=""ID"
            Me.ProgressBar1.Value = 0
            Dim text2 As String = text
            Dim num As Integer = 1
            Dim arg_176_0 As Integer
            Dim num2 As Integer
            Do

                Me.ProgressBar1.Maximum = 100
                Me.ProgressBar1.[Step] = 1
                If TextBox3.Text = "" Then

                    Dim input As String = webClient.DownloadString(String.Concat(New String() {"http://www.bing.com/search?q=ip%3A", text2, "+", "&first=" & Conversions.ToString(num), "&FORM=PERE"}))

                    Try
             


                        Dim enumerator As IEnumerator = New Regex(pattern).Matches(input).GetEnumerator()
                        While enumerator.MoveNext()
                            Dim match As Match = CType(enumerator.Current, Match)
                            Dim value As String = match.Groups(1).Value
                            Dim uri As Uri = New Uri(value)
                            Me.ListBox1.Items.Add("http://" + uri.Host + "/")

                        End While

                    Finally




                        Dim enumerator As IEnumerator
                        Dim flag As Boolean = TypeOf enumerator Is IDisposable

                        If flag Then
                            TryCast(enumerator, IDisposable).Dispose()

                        End If
                    End Try
                Else

                    Dim input As String = webClient.DownloadString(String.Concat(New String() {"http://www.bing.com/search?q=ip%3A", text2, "+", TextBox3.Text, "&first=" & Conversions.ToString(num), "&FORM=PERE"}))
                    Try
                        Dim enumerator As IEnumerator = New Regex(pattern).Matches(input).GetEnumerator()
                        While enumerator.MoveNext()
                            Dim match As Match = CType(enumerator.Current, Match)
                            Dim value As String = match.Groups(1).Value
                            Dim uri As Uri = New Uri(value)
                            Me.ListBox1.Items.Add("http://" + uri.Host + "/")
                        End While

                    Finally




                        Dim enumerator As IEnumerator
                        Dim flag As Boolean = TypeOf enumerator Is IDisposable

                        If flag Then
                            TryCast(enumerator, IDisposable).Dispose()

                        End If
                    End Try
                End If
                num += 10
                Me.ProgressBar1.PerformStep()

                num += 1
                arg_176_0 = num
                num2 = TextBox2.Text
            Loop While arg_176_0 <= num2
            Me.ProgressBar1.Value = 100

            If CheckBox1.Checked = False Then
                Button2.Enabled = True
                Button3.Enabled = True

            Else
                Button2.Enabled = False
                Button3.Enabled = False


                Dim sb As New StringBuilder

                For Each item In ListBox1.Items
                    sb.AppendLine(item.ToString())
                Next

                Try
                    If ListBox1.Items.Count > 0 Then
                        Dim chars As Char() = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
                        Dim total As Integer = 10
                        Dim cur As Integer = 0
                        Dim endStr As String = ""
                        Dim r As New Random
                        Do Until cur >= total
                            Dim rr As Integer = r.Next(chars.Count())
                            endStr &= chars(rr)
                            rr = Nothing
                            cur += 1

                        Loop
                        Dim kirkuk As String
                        kirkuk = "sharo_"
                        If (Not System.IO.Directory.Exists("Result")) Then
                            System.IO.Directory.CreateDirectory("Result")
                        End If

                        System.IO.File.WriteAllText(("Result\" & kirkuk & endStr & ".txt"), sb.ToString())



                    Else





                    End If


                Catch ex As Exception

                End Try


                Me.ListBox1.Items.Clear()

            End If

            System.IO.File.AppendAllText(("ip-scanned.txt"), TextBox1.Text)

            TextBox1.Text = ""


        Next

        Me.Label1.Text = Conversions.ToString(Me.ListBox1.Items.Count)

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Button2.Enabled = True
            Button3.Enabled = True

        Else
            Button2.Enabled = False
            Button3.Enabled = False

        End If
    End Sub
End Class
