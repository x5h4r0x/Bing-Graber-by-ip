﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Bing Grabber")>
<Assembly: AssemblyDescription("Bing Grabber by x5h4r0x")>
<Assembly: AssemblyCompany("Bing Grabber by x5h4r0x")>
<Assembly: AssemblyProduct("Bing Grabber by x5h4r0x")>
<Assembly: AssemblyCopyright("Copyright ©  2016 by x5h4r0x")>
<Assembly: AssemblyTrademark("x5h4r0x")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c1307084-39a9-4bcf-a696-aee5ee19870c")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
